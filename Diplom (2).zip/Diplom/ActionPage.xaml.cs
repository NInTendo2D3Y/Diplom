﻿using Diplom.DB;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Diplom
{
    /// <summary>
    /// Логика взаимодействия для ActionPage.xaml
    /// </summary>
    public partial class ActionPage : Page
    {

        public static DB.DiplomEntities Connector = Class.Connector.GetDatabase();
        public static ObservableCollection<DB.ActionProduct> ActionProducts;

        public class quantitySorts
        {
            public string DisplayName { get; set; }
            public string PropertyName { get; set; }
            public bool Ascending { get; set; }
        }
        int viewcount = 0;
        int totalcount = 0;
        public static List<quantitySorts> QuantitySorts { get; set; } = new List<quantitySorts>()
        {
            new quantitySorts(){DisplayName="Без сортировки", PropertyName=null, Ascending=true},
            new quantitySorts(){DisplayName="Возрастание количества", PropertyName="quantity", Ascending=true},
            new quantitySorts(){DisplayName="Убывание количества", PropertyName="quantity", Ascending=false},
        };
        
        public ActionPage()
        {
            InitializeComponent();

            ActionProducts = new ObservableCollection<DB.ActionProduct>(Connector.ActionProducts.Where(ap => ap.StatusProduct == "Списано").ToList()); ;
           
            ProductList.ItemsSource = ActionProducts;

            SortCombo.SelectedIndex = 0;
            viewcount = ActionProducts.Count;
            totalcount = ActionProducts.Count;
            
                
                
            
            DataContext = this;
        }

        private void SearchText_TextChanged(object sender, TextChangedEventArgs e)
        {
            Search(SearchText.Text.Trim());
        }
        private void Search(string substring)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ProductList.ItemsSource);
            if (view == null) return;
            viewcount = 0;
            view.Filter = new Predicate<object>(obj =>
            {
                bool IsView = ((DB.ActionProduct)obj).Name.ToLower().Contains(substring.ToLower());
                if (IsView) viewcount++;
                return IsView;
            });
            LabelCount.Content = $"{viewcount}/{totalcount}";
        }

        private void SortCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            quantitySorts itemSorting = SortCombo.SelectedItem as quantitySorts;
            Sort(itemSorting.PropertyName, itemSorting.Ascending);
        }
        private void Sort(string property, bool asc)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(ProductList.ItemsSource);
            if (view == null) return;
            view.SortDescriptions.Clear();
            if (property != null)
            {
                view.SortDescriptions.Add(new SortDescription(property, asc ? ListSortDirection.Ascending : ListSortDirection.Descending));
            }
        }
       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void RefreshLis(object sender, RoutedEventArgs e)
        {
            ProductList.Items.Refresh();
        }

        private void ProductList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void GoDay(object sender, RoutedEventArgs e)
        {
            if (ProductList.SelectedItem == null) return;
            var seletedProduct = ProductList.SelectedItem as ActionProduct;
            if (seletedProduct != null)
            {
                var helper = new Class.WordHelper("blankotchetov.docx");
                ActionProduct actionProduct = new ActionProduct();
                var items = new Dictionary<string, string>
                {
                    {"<NameProduct>", actionProduct.Name} ,
                    {"<DateTime>",Convert.ToString(actionProduct.DateAction)},
                    {"<DateTimeNow>",Convert.ToString(DateTime.Now)},
                    {"<Status>",actionProduct.StatusProduct},
                    {"<ProduxtQuntitu>",Convert.ToString(actionProduct.ProductQuantity)}
                };
                helper.Process(items);
            }
        }

        //private void GoMounth(object sender, RoutedEventArgs e)
        //{
        //    if (ProductList.SelectedItem == null) return;
        //    var seletedProduct = ProductList.SelectedItem as ActionProduct;
        //    if (seletedProduct != null)
        //    {

        //        var helper = new Class.WordHelper("blankotchetov.docx");
        //        ActionProduct actionProduct = new ActionProduct();
        //        var items = new Dictionary<string, string>
        //        {
        //            {"<NameProduct>", actionProduct.Name} ,
        //            {"<DateTime>",Convert.ToString(actionProduct.DateAction)},
        //            {"<DateTimeNow>",Convert.ToString(DateTime.Now)},
        //            {"<Status>",actionProduct.StatusProduct},
        //            {"<ProduxtQuntitu>",Convert.ToString(actionProduct.ProductQuantity)}
        //        };
        //    }
        //}
    }
}
